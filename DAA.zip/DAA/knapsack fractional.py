
def knapsack(values, weights, capacity):
    items = sorted(
        zip(values, weights),
        key=lambda x: x[0] / x[1],
        reverse=True
    )

    maximum_value = 0.0

    for value, weight in items:
        if weight <= capacity:
            capacity -= weight
            maximum_value += value
        else:
            maximum_value += value * capacity / weight
            break

    return maximum_value


while True:
    n = int(input('Enter number of items: '))
    values = [int(i) for i in input("Enter values of items: ").split()]
    weights = [int(i) for i in input("Enter weights of items: ").split()]
    capacity = int(input("Enter maximum weight: "))

    maximum_value = knapsack(values, weights, capacity)

    print('The maximum value of items that can be carried:', maximum_value)
