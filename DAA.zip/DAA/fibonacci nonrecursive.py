
def fibonacci_non_recursive(n: int):
    if n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        dp = [0] * n
        dp[0] = 0
        dp[1] = 1

        for i in range(2, n):
            dp[i] = dp[i - 1] + dp[i - 2]

        return dp[n - 1]


n = int(input("Enter value of n (nth Fibonacci number): "))
print(f"Fibonacci Number (Non-Recursive): {fibonacci_non_recursive(n)}")
